#include <fstream>
#include <string.h>
#include <stdio.h>
using namespace std;

ifstream fin("text.in");
ofstream fout("text.out");

int main()
{
    char a[50];
    fin.get(a,50);
    for(int i=0;i<strlen(a);i++)
    {
        if(isdigit(a[i]))
        {
            fout<<a[i];
            if(isalpha(a[i+1]))
                fout<<endl;
        }
    }
    fin.close();
    fout.close();
}
